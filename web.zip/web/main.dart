// Copyright (c) 2016, <your name>. All rights reserved. Use of this source code
// is governed by a BSD-style license that can be found in the LICENSE file.

import 'dart:html';

void main() {
  var  string2Var=document.querySelector('#output');
  string2Var..text="点击合并";
  string2Var..onClick.listen(addString2);
}
void addString2(MouseEvent  event) {
  var s1 = new Map();
  s1['first'] = "Hello,";
  s1['second'] = "world";
  s1.forEach((k, v) {
    querySelector('#output').text += v;
  });
}
 // var text=querySelector('#output').text;
 // var buffer=new StringBuffer();


 // querySelector('#output').text=s1['first']+s1['second'];
 // querySelector('#output').text=s1['first']+s1['second'];


